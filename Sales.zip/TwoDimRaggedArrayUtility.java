import java.io.*;
public class TwoDimRaggedArrayUtility {

	    public static double[][] readFile(File file) throws FileNotFoundException {
	        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
	            String line;
	            double[][] data = new double[0][];
	            int row = 0;
	            while ((line = br.readLine()) != null) {
	                String[] values = line.split(" ");
	                double[] rowValues = new double[values.length];
	                for (int i = 0; i < values.length; i++) {
	                    rowValues[i] = Double.parseDouble(values[i]);
	                }
	                data = java.util.Arrays.copyOf(data, data.length + 1);
	                data[row++] = rowValues;
	            }
	            return data;
	        } catch (IOException ex) {
	            ex.printStackTrace();
	            return new double[0][0];
	        }
	    }

	    public static void writeToFile(double[][] data, File file) throws IOException {
	        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file))) {
	            for (double[] row : data) {
	                for (int i = 0; i < row.length; i++) {
	                    bw.write((i > 0 ? " " : "") + row[i]);
	                }
	                bw.newLine();
	            }
	        }
	    }

	    public static double getTotal(double[][] data) {
	        double total = 0;
	        for (double[] row : data) {
	            for (double value : row) {
	                total += value;
	            }
	        }
	        return total;
	    }

	    public static double getAverage(double[][] data) {
	        int count = 0;
	        double sum = 0;
	        for (double[] row : data) {
	            for (double value : row) {
	                sum += value;
	                count++;
	            }
	        }
	        return sum / count;
	    }

	    public static double getRowTotal(double[][] data, int rowIndex) {
	        double total = 0;
	        for (double value : data[rowIndex]) {
	            total += value;
	        }
	        return total;
	    }

	    public static double getColumnTotal(double[][] data, int columnIndex) {
	        double total = 0;
	        for (double[] row : data) {
	            if (columnIndex < row.length) {
	                total += row[columnIndex];
	            }
	        }
	        return total;
	    }

	    public static double getHighestInRow(double[][] data, int rowIndex) {
	        return java.util.Arrays.stream(data[rowIndex]).max().getAsDouble();
	    }

	    public static int getHighestInRowIndex(double[][] data, int rowIndex) {
	        double max = getHighestInRow(data, rowIndex);
	        for (int i = 0; i < data[rowIndex].length; i++) {
	            if (data[rowIndex][i] == max) return i;
	        }
	        return -1;
	    }

	    public static double getLowestInRow(double[][] data, int rowIndex) {
	        return java.util.Arrays.stream(data[rowIndex]).min().getAsDouble();
	    }

	    public static int getLowestInRowIndex(double[][] data, int rowIndex) {
	        double min = getLowestInRow(data, rowIndex);
	        for (int i = 0; i < data[rowIndex].length; i++) {
	            if (data[rowIndex][i] == min) return i;
	        }
	        return -1;
	    }

	    public static double getHighestInColumn(double[][] data, int columnIndex) {
	        double max = Double.MIN_VALUE;
	        for (double[] row : data) {
	            if (columnIndex < row.length && row[columnIndex] > max) {
	                max = row[columnIndex];
	            }
	        }
	        return max;
	    }

	    public static int getHighestInColumnIndex(double[][] data, int columnIndex) {
	        double max = getHighestInColumn(data, columnIndex);
	        for (int i = 0; i < data.length; i++) {
	            if (columnIndex < data[i].length && data[i][columnIndex] == max) return i;
	        }
	        return -1;
	    }

	    public static double getLowestInColumn(double[][] data, int columnIndex) {
	        double min = Double.MAX_VALUE;
	        for (double[] row : data) {
	            if (columnIndex < row.length && row[columnIndex] < min) {
	                min = row[columnIndex];
	            }
	        }
	        return min;
	    }

	    public static int getLowestInColumnIndex(double[][] data, int columnIndex) {
	        double min = getLowestInColumn(data, columnIndex);
	        for (int i = 0; i < data.length; i++) {
	            if (columnIndex < data[i].length && data[i][columnIndex] == min) return i;
	        }
	        return -1;
	    }

	    public static double getHighestInArray(double[][] data) {
	        double max = Double.MIN_VALUE;
	        for (double[] row : data) {
	            for (double value : row) {
	                if (value > max) max = value;
	            }
	        }
	        return max;
	    }

	    public static double getLowestInArray(double[][] data) {
	        double min = Double.MAX_VALUE;
	        for (double[] row : data) {
	            for (double value : row) {
	                if (value < min) min = value;
	            }
	        }
	        return min;
	    }

		public static int getMaxColumns(double[][] data) {
			// TODO Auto-generated method stub
			return 0;
		}

}
