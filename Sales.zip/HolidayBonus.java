
public class HolidayBonus {


	    private static final double HIGH_BONUS = 500.0;
	    private static final double LOW_BONUS = 100.0;
	    private static final double OTHER_BONUS = 300.0;

	    public static double[] calculateHolidayBonus(double[][] data) {
	        double[] bonuses = new double[data.length];
	        for (int col = 0; col < getMaxColumns(data); col++) {
	            int highIndex = TwoDimRaggedArrayUtility.getHighestInColumnIndex(data, col);
	            int lowIndex = TwoDimRaggedArrayUtility.getLowestInColumnIndex(data, col);
	            for (int row = 0; row < data.length; row++) {
	                if (col < data[row].length) {
	                    if (row == highIndex) {
	                        bonuses[row] += HIGH_BONUS;
	                    } else if (row == lowIndex) {
	                        bonuses[row] += LOW_BONUS;
	                    } else {
	                        bonuses[row] += OTHER_BONUS;
	                    }
	                }
	            }
	        }
	        return bonuses;
	    }

	    public static double calculateTotalHolidayBonus(double[][] data) {
	        double total = 0;
	        double[] bonuses = calculateHolidayBonus(data);
	        for (double bonus : bonuses) {
	            total += bonus;
	        }
	        return total;
	    }

	    private static int getMaxColumns(double[][] data) {
	        int maxCols = 0;
	        for (double[] row : data) {
	            if (row.length > maxCols) {
	                maxCols = row.length;
	            }
	        }
	        return maxCols;
	    }
}
