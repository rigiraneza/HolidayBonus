import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

public class HolidayDataGUI extends JFrame {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextArea textArea;
    private JButton loadButton, copyButton;
    private File selectedFile;
    private double[][] salesData;

    public HolidayDataGUI() {
        super("Retail District #5 Sales Data");

        
        setLayout(new BorderLayout());

        
        textArea = new JTextArea(20, 50);
        textArea.setEditable(false);
        add(new JScrollPane(textArea), BorderLayout.CENTER);

        
        JPanel buttonPanel = new JPanel();
        loadButton = new JButton("Load Sales Data");
        copyButton = new JButton("Copy File");
        buttonPanel.add(loadButton);
        buttonPanel.add(copyButton);
        add(buttonPanel, BorderLayout.SOUTH);

       
        loadButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int option = fileChooser.showOpenDialog(HolidayDataGUI.this);
                if (option == JFileChooser.APPROVE_OPTION) {
                    selectedFile = fileChooser.getSelectedFile();
                    loadSalesData(selectedFile);
                }
            }
        });

        copyButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                copyFile();
            }
        });

        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void loadSalesData(File file) {
        try {
            salesData = TwoDimRaggedArrayUtility.readFile(file);
            displayData(salesData);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error reading file: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void displayData(double[][] data) {
        StringBuilder builder = new StringBuilder();
        double[] storeTotals = new double[data.length];
        double[] categoryTotals = new double[TwoDimRaggedArrayUtility.getMaxColumns(data)];
        double[] bonuses = HolidayBonus.calculateHolidayBonus(data);
        double totalBonus = HolidayBonus.calculateTotalHolidayBonus(data);

        for (int i = 0; i < data.length; i++) {
            storeTotals[i] = TwoDimRaggedArrayUtility.getRowTotal(data, i);
            for (int j = 0; j < data[i].length; j++) {
                if (j == TwoDimRaggedArrayUtility.getHighestInColumnIndex(data, j)) {
                    builder.append("<html><span style='color:green;'>").append(data[i][j]).append("</span></html> ");
                } else if (j == TwoDimRaggedArrayUtility.getLowestInColumnIndex(data, j)) {
                    builder.append("<html><span style='color:red;'>").append(data[i][j]).append("</span></html> ");
                } else {
                    builder.append(data[i][j]).append(" ");
                }
                categoryTotals[j] += data[i][j];
            }
            builder.append(" | Total: ").append(storeTotals[i]);
            builder.append(" | Bonus: ").append(bonuses[i]);
            builder.append("\n");
        }
        builder.append("\nCategory Totals: ");
        for (double total : categoryTotals) {
            builder.append(total).append(" ");
        }
        builder.append("\nTotal Bonuses: ").append(totalBonus);

        textArea.setText(builder.toString());
    }

    private void copyFile() {
        if (selectedFile != null) {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setSelectedFile(new File(selectedFile.getName()));
            int option = fileChooser.showSaveDialog(HolidayDataGUI.this);
            if (option == JFileChooser.APPROVE_OPTION) {
                File destFile = fileChooser.getSelectedFile();
                try {
                    TwoDimRaggedArrayUtility.writeToFile(salesData, destFile);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Error copying file: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    public static void main(String[] args) {
        new HolidayDataGUI();
    }
}



